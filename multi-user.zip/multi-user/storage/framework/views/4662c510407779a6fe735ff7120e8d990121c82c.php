<h1>User Dashboard</h1>

<a href="/logout">Logout</a>
<?php /**PATH D:\wamp64\www\laravel\multi-user\resources\views/user/dashboard.blade.php ENDPATH**/ ?>